from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm #from django.contrib.localflavor.us.forms.USStateField(*, required=True, widget=None, label=None, initial=None, help_text='', error_messages=None, show_hidden_initial=False, validators=(), localize=False, disabled=False, label_suffix=None) #from django.contrib.localflavor.us.forms.USStateSelect(attrs=None) #from django.contrib.localflavor.us.forms.USZipCodeField(*args, **kwargs)
class UserRegisterForm(UserCreationForm):
#full_name = forms.CharField(max_length = 50)
#adress1 = forms.CharField(max_length = 100)
#adress2 = forms.CharField(max_length = 100, required = False)
#city = forms.CharField(max_length = 100)
#state = forms.USStateSelect()
#zipcode = form.USZipCodeField()


	class Meta:
		model = User
		fields = []

